import * as React from "react";
import { Provider } from "react-redux";
import { AppDrawerNavigator } from "./components/appDrawer";
import { initNavigator } from "../services/navigationService";
import { appStore } from "../services/store";

class AppShell extends React.PureComponent {
    render() {
        return (
            <Provider store={appStore}>
                <AppDrawerNavigator
                    ref={initNavigator}
                />
            </Provider>
        );
    }
}

export { AppShell };
