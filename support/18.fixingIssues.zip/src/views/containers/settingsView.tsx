import * as React from "react";
import { Button, Text, View } from "react-native";
import { NavProps } from "../../helpers/alias";
import { getNavigator } from "../../services/navigationService";
import { styles } from "../../styles";

class SettingsView extends React.PureComponent<NavProps> {
    constructor(props: NavProps) {
        super(props);
    }
    public render() {
        return (
            <View style={styles.settingsContainer}>
                <Text style={styles.settingsText}>Settings</Text>
                <Text style={[styles.settingsText, { fontSize: 34, fontWeight: "200" }]}>H1</Text>
                <Text style={[ styles.settingsText,{fontSize: 28, fontWeight: "100"}]}>H2</Text>
                <Text style={[styles.settingsText,{fontSize: 22 }]}>H3</Text>
                <Text style={[styles.settingsText,{fontSize: 18}]}>Body</Text>
                <Text style={[styles.settingsText,{fontSize: 14 }]}>Small Body</Text>
                <Text style={[styles.settingsText,{fontSize: 10}]}>Score</Text>
                <Text style={[styles.settingsText,{fontSize: 17, fontWeight: "400"}]}>Button Text</Text>
                <Button onPress={this.handleClick} title="Click Me" />
            </View>
        );
    }

    handleClick() {
        getNavigator().goToHome();
    }
}

export { SettingsView };
