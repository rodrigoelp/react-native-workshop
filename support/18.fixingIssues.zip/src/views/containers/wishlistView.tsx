import * as React from "react";
import {
    Button,
    FlatList,
    ListRenderItemInfo,
    Text,
    View
    } from "react-native";
import { connect } from "react-redux";
import { Movie } from "../../models";
import { getNavigator } from "../../services/navigationService";
import { ActionDefs, actions, FlixStore } from "../../services/store";
import { styles } from "../../styles";

type WishlistJoinedProps = FlixStore &
    ActionDefs;

class WishlistView extends React.PureComponent<WishlistJoinedProps> {
    constructor(props: WishlistJoinedProps) {
        super(props);
    }

    public render() {
        return (
            <View style={styles.wishlistContainer}>
                <View style={{ flex: 1 }}>
                    <Text style={styles.wishlistText}>Wishlist</Text>
                    <FlatList
                        data={this.props.wishlist}
                        keyExtractor={this.genKeyForMovie}
                        renderItem={this.renderItem}
                    />
                </View>
                <Button onPress={this.handleClick} title="Go to settings." />
            </View>
        );
    }

    genKeyForMovie = (movie: Movie, index: number) => {
        return `${movie.id.toString()}`;
    };

    renderItem = (item: ListRenderItemInfo<Movie>) => {
        return (
            <View style={{ flex: 1 }}>
                <Text>{item.item.title}</Text>
                <Button
                    onPress={() => this.props.removeFromWishlist(item.item)}
                    title="Delete"
                />
            </View>
        );
    };

    handleClick() {
        getNavigator().goToSettings();
    };
}

const WishlistContainer = connect(
    s => s,
    actions
)(WishlistView);

export { WishlistView, WishlistContainer };
