import * as React from "react";
import { Text, View } from "react-native";
import Flag from "react-native-flags";
import { NavigationScreenProps } from "react-navigation";
import { connect } from "react-redux";
import { ImageLibrary } from "../../services/imageLibrary";
import { convertToCountry } from "../../services/languageConversion";
import { ActionDefs, actions, FlixStore } from "../../services/store";
import { styles } from "../../styles";
import { FadeInBackgroundImage } from "../components/backgroundFadeInImage";
import { StyledButton } from "../components/button";

type DetailsViewJoinedProps = FlixStore & NavigationScreenProps & ActionDefs;

class DetailsView extends React.PureComponent<DetailsViewJoinedProps> {
    static navigationOptions = ({ navigation }: NavigationScreenProps) => ({
        title: navigation.getParam("movieTitle", "Details")
    });

    constructor(props: DetailsViewJoinedProps) {
        super(props);
        this.addToWishlist = this.addToWishlist.bind(this);
    }

    componentDidMount() {
        if (this.props.selectedMovie) {
            this.props.navigation.setParams({
                movieTitle: this.props.selectedMovie.title
            });
        }
    }

    public render() {
        const movie = this.props.selectedMovie;
        if (!movie) return null;
        return (
            <View style={styles.detailsContainer}>
                <FadeInBackgroundImage movie={movie} />
                <View style={{ flex: 1, margin: 36 }}>
                    <Text style={[styles.detailsText, styles.textH1]}>
                        {movie.title}
                    </Text>

                    <Text style={[styles.detailsText, styles.textH2]}>
                        Overview
                    </Text>
                    <Text style={{ marginVertical: 16 }}>{movie.overview}</Text>

                    <View style={styles.detailsRowContainer}>
                        <Text
                            style={[
                                styles.detailsText,
                                styles.textH3,
                                styles.baseContainer
                            ]}
                        >
                            Released on:{" "}
                        </Text>
                        <Text
                            style={[
                                styles.detailsText,
                                styles.detailsExtraInfoText
                            ]}
                        >
                            {movie.release_date}
                        </Text>
                    </View>

                    <View style={styles.detailsRowContainer}>
                        <Text
                            style={[
                                styles.detailsText,
                                styles.textH3,
                                styles.baseContainer
                            ]}
                        >
                            Score:
                        </Text>
                        <Text style={[styles.detailsText, styles.textH3]}>
                            {movie.vote_average}{" "}
                        </Text>
                        <Text style={[styles.detailsText, styles.textSmall]}>
                            / 10
                        </Text>
                    </View>
                    <View style={styles.detailsRowContainer}>
                        <Text
                            style={[
                                styles.detailsText,
                                styles.textH3,
                                styles.baseContainer
                            ]}
                        >
                            Voted:
                        </Text>
                        <Text style={[styles.detailsText, styles.textNormal]}>
                            {movie.vote_count}
                            {" times"}
                        </Text>
                    </View>

                    <Flag
                        code={convertToCountry(movie.original_language)}
                        size={32}
                    />
                </View>
                <StyledButton
                    onPress={this.addToWishlist}
                    title="Add to wishlist"
                    icon={ImageLibrary.iconFave}
                    containerStyle={styles.detailsButtonContainer}
                />
            </View>
        );
    }

    addToWishlist() {
        const movie = this.props.selectedMovie;
        if (movie == 0) return;
        this.props.addToWishlist(movie);
    }
}

const DetailsContainer = connect(
    s => s,
    actions
)(DetailsView);

export { DetailsView, DetailsContainer };
