import * as React from "react";
import {
    ActivityIndicator,
    FlatList,
    ListRenderItemInfo,
    TextStyle,
    View
    } from "react-native";
import { connect } from "react-redux";
import { Movie } from "../../models";
import { getItemMinSize } from "../../services/screenSizes";
import {
    ActionDefs,
    actions,
    BackgroundProcessStatus,
    FlixStore
    } from "../../services/store";
import { styles } from "../../styles";
import { TouchableMovieItem } from "../components/touchableMovieItem";

interface HomeViewProps {
    isLoading: boolean;
}

type HomeViewJoinedProps = HomeViewProps & FlixStore & ActionDefs;

class HomeView extends React.PureComponent<HomeViewJoinedProps> {
    constructor(props: HomeViewJoinedProps) {
        super(props);
        this.state = {
            refreshing: false
        };
        this.renderMovie = this.renderMovie.bind(this);
        this.showMovieDetails = this.showMovieDetails.bind(this);
        this.renderFooter = this.renderFooter.bind(this);
        this.handleEndReached = this.handleEndReached.bind(this);
    }

    componentDidMount() {
        if (this.props.movies.length > 0) {
            this.props.fetchPage(1);
        }
    }

    render() {
        const { numColumns } = getItemMinSize();
        return (
            <View style={styles.homeContainer}>
                <FlatList
                    style={styles.homeListContainer}
                    contentContainerStyle={{
                        justifyContent: "center",
                        paddingHorizontal: 16
                    }}
                    numColumns={numColumns}
                    data={this.props.movies}
                    renderItem={this.renderMovie}
                    keyExtractor={this.getKeyForMovie}
                    onEndReachedThreshold={1}
                    onEndReached={this.handleEndReached}
                    ListFooterComponent={this.renderFooter}
                />
            </View>
        );
    }

    renderFooter(): JSX.Element {
        if (!this.props.isLoading) return <View />;
        const { color } = styles.homeActivityIndicator as TextStyle;
        return (
            <View style={styles.homeListFooter}>
                <ActivityIndicator
                    size="large"
                    animating={true}
                    color={color}
                />
            </View>
        );
    }

    renderMovie(x: ListRenderItemInfo<Movie>): JSX.Element {
        const size = getItemMinSize();
        return (
            <TouchableMovieItem
                itemSize={size}
                movie={x.item}
                onPress={this.showMovieDetails}
            />
        );
    }

    fetchLatestPage() {
        this.props.fetchLatestPage();
    }

    handleEndReached() {
        this.fetchLatestPage();
    }

    getKeyForMovie(movie: Movie) {
        return `${movie.id}`;
    }

    showMovieDetails(movie: Movie): void {
        this.props.selectMovie(movie);
    }
}

const HomeContainer = connect(
    (s: FlixStore) => ({
        ...s,
        isLoading: s.processStatus !== BackgroundProcessStatus.Idle
    }),
    actions
)(HomeView);

export { HomeView, HomeContainer };
