import * as React from "react";
import { Animated, Image } from "react-native";
import { Movie } from "../../models";
import { getDatabase } from "../../services/remoteDatabase";
import { styles } from "../../styles";

interface FadeInBackgroundImageProps {
    movie: Movie;
}

class FadeInBackgroundImage extends React.PureComponent<
    FadeInBackgroundImageProps
> {
    constructor(props: FadeInBackgroundImageProps) {
        super(props);
    }

    componentDidMount() {
        // TODO: let's start an animation here.
    }

    componentWillUnmount() {
        // TODO: let's stop the animation if for some reason is still going.
    }

    render() {
        const backgroundSource = this.getBackground(this.props.movie);
        return (
            <Animated.View
                style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    right: 0,
                    width: "100%",
                    height: "100%",
                }}
            >
                <Image
                    source={backgroundSource}
                    style={styles.baseContainer}
                />
            </Animated.View>
        );
    }

    getBackground(movie: Movie) {
        const { backdrop_path } = movie;
        const database = getDatabase();
        const imageSource = backdrop_path
            ? database.getBackdropFor(movie)
            : database.getPosterFor(movie);
        return imageSource;
    }
}

export { FadeInBackgroundImage };
