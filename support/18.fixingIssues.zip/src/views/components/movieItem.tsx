import * as React from "react";
import {
    Image,
    ImageURISource,
    Text,
    View
    } from "react-native";
import Flag from "react-native-flags";
import { Movie } from "../../models";
import { ImageLibrary } from "../../services/imageLibrary";
import { convertToCountry } from "../../services/languageConversion";
import { styles } from "../../styles";

type MovieItemProps = {
    movie: Movie;
    poster: ImageURISource | number;
    maxScore: number;
    size: { minHeight: number; minWidth: number };
};

class MovieItem extends React.PureComponent<MovieItemProps> {
    constructor(props: MovieItemProps) {
        super(props);
    }

    render() {
        const { minHeight, minWidth } = this.props.size;
        return (
            <View
                style={[
                    styles.homeItemContainer,
                    {
                        minHeight,
                        minWidth
                    }
                ]}
            >
                {this.renderThumbnailAsBackground(
                    this.props.poster,
                    this.props.size.minHeight,
                    this.props.size.minWidth
                )}
                <View style={styles.baseContainer}>
                    {this.renderTopSection(this.props.movie)}
                    {this.renderBottomSection(
                        this.props.movie,
                        this.props.size
                    )}
                </View>
            </View>
        );
    }

    renderThumbnailAsBackground(
        poster: ImageURISource | number,
        minHeight: number,
        minWidth: number
    ) {
        return (
            <Image
                style={{ position: "absolute", minHeight, minWidth }}
                source={poster}
                resizeMode="cover"
            />
        );
    }

    renderTopSection(movie: Movie) {
        const { adult, vote_average, original_language } = movie;
        return (
            <View style={styles.baseContainer}>
                {this.renderFaved()}
                {this.renderScore(vote_average)}
                {this.renderExtraInfo(adult, original_language)}
            </View>
        );
    }

    renderFaved() {
        return (
            <View />
        );
    }

    renderScore(vote_average: number) {
        return (
            <View style={styles.homeItemScoreContainer}>
                <View style={styles.homeItemScoreTopContainer}>
                    <Text style={styles.homeItemScoreValue}>
                        {vote_average}
                    </Text>
                </View>
                <View style={styles.homeItemScoreBottomContainer}>
                    <Text style={styles.homeItemScoreLabel}>Score</Text>
                </View>
            </View>
        );
    }

    renderExtraInfo(adult: boolean, original_language: string) {
        const countryCode = convertToCountry(original_language);
        const restrictedImg = adult ? (
            <Image
                style={styles.homeItemExtraIcon}
                source={ImageLibrary.restricted}
            />
        ) : (
            <View />
        );
        return (
            <View style={styles.homeItemExtraContainer}>
                {restrictedImg}
                <Flag code={countryCode} size={24} style={{ marginTop: 8 }} />
            </View>
        );
    }

    renderBottomSection(movie: Movie, size: { minWidth: number }) {
        const { title } = movie;
        return (
            <View style={styles.homeItemTitleContainer}>
                <Text
                    numberOfLines={2}
                    ellipsizeMode="tail"
                    style={[
                        styles.homeItemTitleText,
                        {
                            maxWidth: size.minWidth
                        }
                    ]}
                >
                    {title}
                </Text>
            </View>
        );
    }
}

export { MovieItem };
