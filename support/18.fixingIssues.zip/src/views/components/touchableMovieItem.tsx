import * as React from "react";
import { TouchableOpacity } from "react-native";
import { MovieItem } from "./movieItem";
import { Movie } from "../../models";
import { getDatabase } from "../../services/remoteDatabase";

interface TouchableMovieItemProps {
    movie: Movie;
    itemSize: { minHeight: number; minWidth: number};
    onPress: (movie: Movie) => void;
}

class TouchableMovieItem extends React.PureComponent<TouchableMovieItemProps> {
    constructor(props: TouchableMovieItemProps) {
        super(props);
        this.handlePress = this.handlePress.bind(this);
    }

    render() {
        const { movie } = this.props;
        return (
            <TouchableOpacity onPress={this.handlePress}>
                <MovieItem
                    size={this.props.itemSize}
                    poster={getDatabase().getPosterFor(movie)}
                    maxScore={10}
                    movie={movie}
                />
            </TouchableOpacity>
        );
    }

    handlePress() {
        this.props.onPress(this.props.movie);
    }
}

export { TouchableMovieItem };
