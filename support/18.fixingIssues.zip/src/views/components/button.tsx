import * as React from "react";
import {
    Image,
    ImageURISource,
    Text,
    TextStyle,
    TouchableOpacity,
    View,
    ViewStyle
    } from "react-native";
import { styles } from "../../styles";

interface StyledButtonProps {
    onPress: () => void;
    title: string;
    style?: ViewStyle;
    titleStyle?: TextStyle;
    containerStyle?: ViewStyle;
    icon?: ImageURISource | number;
}

class StyledButton extends React.PureComponent<StyledButtonProps> {
    render() {
        const { style, titleStyle, containerStyle } = this.props;
        const appliedTitleStyle = [
            styles.defaultButtonTitle,
            titleStyle ? titleStyle : {}
        ];
        const appliedContStyle = [
            styles.defaultButton,
            containerStyle ? containerStyle : {}
        ];
        const appliedStyle = [styles.defaultButtonSpacing, style ? style : {}];
        return (
            <TouchableOpacity onPress={this.props.onPress} style={appliedStyle}>
                <View style={appliedContStyle}>
                    {this.renderImage()}
                    <Text style={appliedTitleStyle}>{this.props.title}</Text>
                </View>
            </TouchableOpacity>
        );
    }

    renderImage() {
        if (this.props.icon) {
            return (
                <Image
                    source={this.props.icon}
                    style={{
                        resizeMode: "cover",
                        height: 24,
                        width: 24,
                        marginRight: 8
                    }}
                />
            );
        }
        return null;
    }
}

export { StyledButton };
