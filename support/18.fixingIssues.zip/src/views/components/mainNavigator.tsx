import { createStackNavigator, NavigationRouteConfigMap, StackNavigatorConfig } from "react-navigation";
import { Routes } from "../../routes";
import { DetailsContainer } from "../containers/detailsView";
import { HomeContainer } from "../containers/homeView";
import { SettingsView } from "../containers/settingsView";
import { WishlistContainer } from "../containers/wishlistView";

const stackRouteMap: NavigationRouteConfigMap = {
    [Routes.Home]: {
        path: Routes.Home,
        screen: HomeContainer,
        navigationOptions: { headerTitle: "FlixFlix!" }
    },
    [Routes.Details]: {
        path: Routes.Details,
        screen: DetailsContainer
    },
    [Routes.Wishlist]: {
        path: Routes.Wishlist,
        screen: WishlistContainer,
        navigationOptions: { headerTitle: "My Wishlist" }
    },
    [Routes.Settings]: { path: Routes.Settings, screen: SettingsView }
};

const stackConfig: StackNavigatorConfig = {
    initialRouteName: Routes.Home,
    initialRouteParams: {},
    headerMode: "float"
    // navigationOptions: ({ navigation }) => ({
    //     headerStyle: { backgroundColor: "green" },
    //     title: "Start",
    //     headerLeft: (
    //         <Text onPress={() => DrawerActions.toggleDrawer()}>Menu</Text>
    //     )
    // })
};

const MainNavigator = createStackNavigator(stackRouteMap, stackConfig);

export { MainNavigator };
