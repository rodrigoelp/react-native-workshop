interface MovieSummary {
    id: number;
    title: string;
    vote_average: number;
    popularity: number;
    poster_path: string;
    original_language: string;
}

/**
 * Complete stored information about a movie.
 */
interface Movie {
    id: number;
    title: string;
    overview: string;
    video: boolean;
    adult: boolean;
    popularity: number;
    vote_count: number;
    vote_average: number;
    original_title: string;
    original_language: string;
    poster_path: string | null;
    backdrop_path: string | null;
    release_date: string;
    genre_ids: number[];
}

interface Page {
    page: number;
    total_results: number;
    total_pages: number;
    results: Movie[];
}

interface SummarizedPage {
    page: number;
    total_results: number;
    total_pages: number;
    results: MovieSummary[];
}

interface MovieDatabase {
    all: Movie[];
}

export { Page, MovieDatabase, Movie,  MovieSummary, SummarizedPage };
