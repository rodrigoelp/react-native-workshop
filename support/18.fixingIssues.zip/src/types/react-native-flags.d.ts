declare module "react-native-flags" {
    import { Component } from "react";
    import { ViewStyle } from "react-native";

    interface FlagProps {
        code: string;
        size?: 16 | 24 | 32 | 48 | 64;
        type?: "shiny" | "flat";
        style?: ViewStyle;
    }

    export default class FlagComponent extends Component<FlagProps> {}
}
