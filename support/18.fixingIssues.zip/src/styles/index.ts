import { createStyleSheet } from "./stylesheetGenerator";

enum Color {
    TextOnDark = "#fff",
    TextOnLight = "#000",
    HomeBg = "#009ab0",
    DetailsBg = "#cfbca6",
    WishlistBg = "#e7d5c0",
    SettingsBg = "#65b7b1",
    PanelBg = "#000000aa",
}

const styles = createStyleSheet({
    home: {
        main: Color.HomeBg,
        foreground: Color.TextOnDark,
    },
    homeItem: {
        main: Color.PanelBg,
        foreground: Color.TextOnDark,
    },
    details: {
        main: Color.DetailsBg,
        foreground: Color.TextOnLight,
    },
    wishlist: {
        main: Color.WishlistBg,
        foreground: Color.TextOnLight,
    },
    settings: {
        main: Color.SettingsBg,
        foreground: Color.TextOnDark,
    },
});

export { styles };
