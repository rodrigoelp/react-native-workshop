import { StyleSheet, TextStyle, ViewStyle } from "react-native";

enum TextSize {
    Header1 = 34,
    Header2 = 28,
    Header3 = 22,
    Text = 18,
    SmallText = 14,
    SmallLabel = 10,
    ButtonText = 17
}

enum FontWeight {
    Header = "200",
    Body = "Normal",
    Button = "400"
}

interface ScreenColorPalette {
    main: string;
    foreground: string;
}

interface ColorPalette {
    home: ScreenColorPalette;
    homeItem: ScreenColorPalette;
    details: ScreenColorPalette;
    wishlist: ScreenColorPalette;
    settings: ScreenColorPalette;
}

function createContainerStyle(
    baseContainer: ViewStyle,
    color: string
): ViewStyle {
    return { ...baseContainer, backgroundColor: color };
}

function createHeaderStyle(
    type: TextSize.Header1 | TextSize.Header2 | TextSize.Header3
): TextStyle {
    return { fontSize: type, fontWeight: FontWeight.Header, marginVertical: 8 };
}

function createTextStyle(color: string): TextStyle {
    return { fontSize: TextSize.Text, color };
}

function createStyleSheet(colorPalette: ColorPalette) {
    const baseContainer: ViewStyle = { flex: 1 };
    const centredContentContainer: ViewStyle = {
        ...baseContainer,
        alignItems: "center",
        justifyContent: "center"
    };
    return StyleSheet.create({
        baseContainer,
        centredContentContainer,
        homeContainer: createContainerStyle(
            baseContainer,
            colorPalette.home.main
        ),
        homeListContainer: baseContainer,
        homeListContentContainer: {
            paddingHorizontal: 16,
            justifyContent: "center"
        },
        homeListFooter: { paddingVertical: 16 },
        homeActivityIndicator: { color: colorPalette.home.foreground },
        homeText: createTextStyle(colorPalette.home.foreground),
        homeItemContainer: {
            borderTopLeftRadius: 16,
            borderBottomRightRadius: 16,
            marginVertical: 8,
            marginHorizontal: 4,
            overflow: "hidden"
        },
        homeItemScoreContainer: createContainerStyle(
            {
                position: "absolute",
                top: 0,
                right: 0,
                borderBottomLeftRadius: 8
            },
            colorPalette.homeItem.main
        ),
        homeItemScoreTopContainer: {
            flex: 1,
            paddingVertical: 4,
            backgroundColor: "white",
            justifyContent: "center",
            alignItems: "center",
            borderBottomLeftRadius: 8
        },
        homeItemScoreBottomContainer: {
            paddingHorizontal: 8,
            paddingVertical: 4,
            borderBottomLeftRadius: 8
        },
        homeItemScoreLabel: { fontSize: TextSize.SmallLabel, color: "white" },
        homeItemScoreValue: { fontSize: TextSize.Text, color: "black" },
        homeItemExtraContainer: {
            position: "absolute",
            bottom: 8,
            right: 8
        },
        homeItemExtraIcon: {
            width: 24,
            height: 24,
            resizeMode: "cover"
        },
        homeItemTitleContainer: {
            backgroundColor: colorPalette.homeItem.main,
            minHeight: 64,
            justifyContent: "center",
            borderTopLeftRadius: 8,
            borderTopRightRadius: 8
        },
        homeItemTitleText: {
            textAlign: "center",
            color: colorPalette.homeItem.foreground
        },
        homeItemFavedContainer: {
            position: "absolute",
            top: 0,
            left: 16,
            backgroundColor: "#ffffffaa",
            paddingBottom: 4,
            paddingHorizontal: 4,
            borderBottomLeftRadius: 8,
            borderBottomRightRadius: 8
        },
        homeItemFavedIcon: { resizeMode: "contain", height: 24, width: 24 },
        detailsContainer: createContainerStyle(
            centredContentContainer,
            colorPalette.details.main
        ),
        detailsText: createTextStyle(colorPalette.details.foreground),
        detailsRowContainer: {
            flexDirection: "row",
            alignSelf: "stretch"
        },
        detailsExtraInfoText: {
            paddingVertical: 8,
            alignSelf: "center",
            fontSize: 14
        },
        detailsButtonContainer: { backgroundColor: colorPalette.home.main },
        wishlistContainer: createContainerStyle(
            centredContentContainer,
            colorPalette.wishlist.main
        ),
        wishlistText: createTextStyle(colorPalette.wishlist.foreground),
        settingsContainer: createContainerStyle(
            centredContentContainer,
            colorPalette.settings.main
        ),
        settingsText: createTextStyle(colorPalette.settings.foreground),
        textH1: createHeaderStyle(TextSize.Header1),
        textH2: createHeaderStyle(TextSize.Header2),
        textH3: createHeaderStyle(TextSize.Header3),
        textNormal: { fontSize: TextSize.Text },
        textSmall: { fontSize: TextSize.SmallText },
        defaultButtonSpacing: { marginVertical: 32, marginHorizontal: 16 },
        defaultButton: {
            paddingHorizontal: 36,
            paddingVertical: 16,
            borderRadius: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "#6f6f6f"
        },
        defaultButtonTitle: { fontSize: TextSize.Text, color: "#fff" }
    });
}

export { createStyleSheet, ColorPalette, ScreenColorPalette };
