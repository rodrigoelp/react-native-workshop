import { AppRegistry } from "react-native";
import { AppShell } from "./views/appShell";

const appName = require("../app.json").name;

AppRegistry.registerComponent(appName, () => AppShell);
