let directory: { [key: string]: string } = {
    en: "US",
    ja: "JP",
    zh: "CN",
    ko: "KR",
    ta: "IN",
    hi: "IN",
    ru: "RU",
    fr: "FR",
    nl: "NL",
    tl: "PH",
    es: "ES",
    it: "IT",
    pt: "PT",
    id: "id",
    cn : "CN",
    th: "TH",
    ml: "ML",
    de: "DE",
    no: "no"
};

function convertToCountry(languageCode: string) {
    const code = directory[languageCode];
    if (code) return code;
    return languageCode.toUpperCase();
}

export { convertToCountry };

