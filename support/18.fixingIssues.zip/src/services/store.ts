import {
    Action,
    applyMiddleware,
    combineReducers,
    createStore,
    Dispatch
    } from "redux";
import thunk from "redux-thunk";
import { getNavigator } from "./navigationService";
import { delay, getDatabase } from "./remoteDatabase";
import { Movie, Page } from "../models";

type Empty = 0;
type OptionalMovie = Movie | Empty;

enum BackgroundProcessStatus {
    Idle,
    Busy
}

/**
 * This defines the shape of the store.
 */
interface FlixStore {
    pages: Page[];
    movies: Movie[];
    selectedMovie: OptionalMovie;
    wishlist: Movie[];
    availablePages: number[];
    processStatus: BackgroundProcessStatus;
}

enum ActionType {
    PageDownloading = "PageDownloading",
    PageDownloaded = "PageDownloaded",
    NewMoviesAvailable = "NewMoviesAvailable",
    DownloadFailed = "DownloadError",
    SelectMovie = "MovieSelected",
    UnselectMovie = "MovieUnselected",
    AddToWishlist = "MovieAddedToWishlist",
    RemoveFromWishlist = "MovieRemovedOfWishlist",
    ClearWishlist = "WishlistCleared",
    PageAdded = "PageAddedToCache"
}

interface ActionWithPayload<TActionType, TPayload> extends Action<TActionType> {
    payload: TPayload;
}

const initialState: FlixStore = {
    pages: [],
    movies: [],
    wishlist: [],
    selectedMovie: 0,
    availablePages: [],
    processStatus: BackgroundProcessStatus.Idle
};

// ###########
// Reducers

function processStatusReducer(
    status: BackgroundProcessStatus = initialState.processStatus,
    action: Action<ActionType>
) {
    if (action.type === ActionType.PageDownloading) {
        return BackgroundProcessStatus.Busy;
    } else if (
        action.type === ActionType.DownloadFailed ||
        action.type === ActionType.PageDownloaded
    ) {
        return BackgroundProcessStatus.Idle;
    }
    return status;
}

function availablePagesReducer(
    availablePages: number[] = initialState.availablePages,
    action: ActionWithPayload<ActionType, number>
) {
    if (
        action.type === ActionType.PageAdded &&
        availablePages.findIndex(x => x === action.payload) === -1
    ) {
        return availablePages.concat(action.payload).sort((a, b) => a - b);
    }
    return availablePages;
}

function moviesReducer(
    movies: Movie[] = initialState.movies,
    action: ActionWithPayload<ActionType, Movie[]>
) {
    if (
        action.type === ActionType.NewMoviesAvailable &&
        action.payload.length > 0 &&
        movies.findIndex(x => action.payload[0].id === x.id) === -1
    ) {
        action.payload.forEach(x => movies.push(x));
    }
    return movies;
}

function pagesReducer(
    pages = initialState.pages,
    action: ActionWithPayload<ActionType, Page>
) {
    if (action.type === ActionType.PageDownloaded) {
        const page = action.payload;
        if (!alreadyHavePage(pages, page.page)) {
            return pages.concat(page);
        }
    }
    return pages;
}

type SelectMovieAction =
    | ActionWithPayload<ActionType.SelectMovie, Movie>
    | Action<ActionType.UnselectMovie>;

function selectedMovieReducer(
    state: OptionalMovie = initialState.selectedMovie,
    action: SelectMovieAction
) {
    if (action.type === ActionType.SelectMovie) {
        return action.payload;
    } else if (action.type === ActionType.UnselectMovie) {
        return initialState.selectedMovie!;
    }

    return state;
}

type WishlistReducerAction =
    | ActionWithPayload<ActionType.AddToWishlist, Movie>
    | ActionWithPayload<ActionType.RemoveFromWishlist, Movie>
    | Action<ActionType.ClearWishlist>;

function wishlistReducer(
    movies: Movie[] = initialState.wishlist,
    action: WishlistReducerAction
) {
    if (action.type === ActionType.AddToWishlist) {
        return movies.concat(action.payload);
    } else if (action.type === ActionType.RemoveFromWishlist) {
        return movies.filter(x => x.id !== action.payload.id);
    } else if (action.type === ActionType.ClearWishlist) {
        return [];
    }
    return movies;
}

//######
// Selectors

function alreadyHavePage(pages: Page[], pageNumber: number) {
    return pages.findIndex(x => x.page === pageNumber) !== -1;
}

function pageAlreadyinStore(pageNumber: number) {
    return alreadyHavePage(appStore.getState().pages, pageNumber);
}

function isDownloading() {
    return appStore.getState().processStatus === BackgroundProcessStatus.Busy;
}

// ############
// Action Creators.

function fetchLatestPage() {
    const { availablePages } = appStore.getState();
    const pageNumber =
        availablePages.length > 0
            ? availablePages[availablePages.length - 1]
            : 0;
    return fetchPage(pageNumber + 1);
}

function fetchPage(pageNumber: number) {
    return (dispatch: Dispatch) => {
        if (pageAlreadyinStore(pageNumber) && isDownloading()) {
            return;
        }

        dispatch({ type: ActionType.PageDownloading });
        getDatabase()
            .getPage(pageNumber)
            .then(delay) // added this intentionally to make it slower.
            .then(page => {
                dispatch({
                    type: ActionType.PageDownloaded,
                    payload: page
                });
                dispatch({
                    type: ActionType.PageAdded,
                    payload: pageNumber
                });
                dispatch({
                    type: ActionType.NewMoviesAvailable,
                    payload: page.results
                });
            })
            .catch(e =>
                dispatch({ type: ActionType.DownloadFailed, payload: e })
            );
    };
}

function selectMovie(movie: Movie) {
    return (dispatch: Dispatch) => {
        dispatch({ type: ActionType.SelectMovie, payload: movie });
        getNavigator().goToDetails();
    };
}

function addToWishlist(movie: Movie) {
    return (dispatch: Dispatch) => {
        dispatch({ type: ActionType.AddToWishlist, payload: movie });
        getNavigator().goToWishlist();
    };
}

function removeFromWishlist(movie: Movie) {
    return { type: ActionType.RemoveFromWishlist, payload: movie };
}

function clearWishlist() {
    return { type: ActionType.ClearWishlist };
}

//##############
// Building the store.

const appStore = createStore(
    combineReducers({
        // the combined shape of the reducers must match the shape of the store.
        pages: pagesReducer,
        movies: moviesReducer,
        selectedMovie: selectedMovieReducer,
        wishlist: wishlistReducer,
        availablePages: availablePagesReducer,
        processStatus: processStatusReducer
    }),
    applyMiddleware(thunk)
);

const actions = {
    fetchPage,
    fetchLatestPage,
    selectMovie,
    addToWishlist,
    removeFromWishlist,
    clearWishlist,
};

interface ActionDefs {
    fetchLatestPage(): any;
    fetchPage(pageNumber: number): any;
    selectMovie(movie: Movie): any;
    addToWishlist(movie: Movie): any;
    removeFromWishlist(movie: Movie): any;
    clearWishlist(): any;
    resetCache(): any;
}

export { appStore, FlixStore, actions, ActionDefs, BackgroundProcessStatus };
