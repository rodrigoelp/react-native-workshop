import { NavigationActions, NavigationDispatch, StackActions } from 'react-navigation';
import { Routes } from '../routes';

interface NavigatorContainer {
    dispatch: NavigationDispatch;
}

class NavigatorService {
    constructor(navigator: NavigatorContainer) {
        this.navigator = navigator;
    }

    private navigator: NavigatorContainer;

    goToDetails() {
        this.navigateToRoute(Routes.Details);
    }

    goToWishlist() {
        this.navigateToRoute(Routes.Wishlist);
    }

    goToSettings() {
        this.navigateToRoute(Routes.Settings);
    }

    goToHome() {
        this.resetToRoute(Routes.Home);
    }

    private navigateToRoute(routeName: Routes) {
        this.navigator.dispatch(NavigationActions.navigate({ routeName }));
    }

    private resetToRoute(routeName: Routes) {
        this.navigator.dispatch(
            StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName })]
            })
        );
    }
}

let instance: NavigatorService;

function initNavigator(navigator: any) {
    // if the instance is not NavigationContainer then it should barf.
    instance = new NavigatorService(navigator);
}

function getNavigator() {
    return instance;
}

export { getNavigator, initNavigator };
