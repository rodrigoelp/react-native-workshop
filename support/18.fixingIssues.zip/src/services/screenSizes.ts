import { Dimensions } from "react-native";

const spaceBetweenItems = 8;
const reserveArea = 32; // 16 on each side.
const navBar = 76;
const maxPerColumnLandscape = 1;
const maxPerRowLandspace = 4;
const maxPerColumnPortrait = 2.6;
const maxPerRowPortrait = 2;

function getItemMinSize(): {
    minHeight: number;
    minWidth: number;
    numColumns: number;
} {
    let minWidth = 0,
        minHeight = 0,
        numColumns = 0;
    const { width, height } = Dimensions.get("window");
    if (width > height) {
        minHeight = (height - reserveArea - navBar) / maxPerColumnLandscape;
        minWidth =
            (width - maxPerColumnLandscape * spaceBetweenItems - 2 * reserveArea) /
            maxPerRowLandspace;
            numColumns = maxPerRowLandspace;
    } else {
        minHeight = (height - reserveArea - navBar) / maxPerColumnPortrait;
        minWidth =
            (width - maxPerRowPortrait * spaceBetweenItems - reserveArea) /
            maxPerRowPortrait;
            numColumns = maxPerRowPortrait;
    }
    return { minHeight, minWidth, numColumns };
}

export { getItemMinSize };
