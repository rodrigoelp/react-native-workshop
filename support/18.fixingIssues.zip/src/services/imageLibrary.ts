
const ImageLibrary = {
    restricted: require("../../static/restricted.png"),
    notFound: require("../../static/nope.png"),
    faved: require("../../static/faved.png"),
    notFaved: require("../../static/faved-not.png"),
    iconFave: require("../../static/icon-fave.png")
}

export { ImageLibrary};