enum Routes {
    Home = "/",
    Details = "/details",
    Settings = "/settings",
    Wishlist = "/wishlist"
}

export { Routes };
