import { NavigationScreenProps } from "react-navigation";

type NavProps = NavigationScreenProps<{}, {}>;

export { NavProps };